#include "Juego.hpp"

int main() {
    Crazy::Juego::Instance();
    Crazy::Juego::Instance()->Iniciar();
    return 0;
}